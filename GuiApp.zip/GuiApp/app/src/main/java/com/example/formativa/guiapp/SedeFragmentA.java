package com.example.formativa.guiapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SedeFragmentA extends Fragment {
// variables de la vista  .

    private CardView cardPlanoA,cardOficinaA,cardLabA,cardOtrosA,cardAuditorioA,cardAulasA;
    MediaPlayer mp;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // se infla la vista para la sede y cargarla cuando se seleccione desde mainactivity .
        return inflater.inflate(R.layout.app_bar_sedea, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
// instaciamos los compoenente que tiene la vista inflada .
        cardPlanoA =(CardView)view.findViewById(R.id.cardIdPlanoA);
        cardOficinaA=(CardView)view.findViewById(R.id.cardIdOfiA);
        cardLabA=(CardView)view.findViewById(R.id.cardIdLabA);
        cardOtrosA=(CardView)view.findViewById(R.id.cardIdOtrosA);
        cardAuditorioA=(CardView)view.findViewById(R.id.cardIdAuditorioA);
        cardAulasA=(CardView)view.findViewById(R.id.cardIdAulasA);
// objeto mediaplayer para reproducciner un tono , cada vez que den el boton .
        mp=MediaPlayer.create(getContext(),R.raw.click);

// llamado del metodo parametos y reproduccion del tono .
        cardPlanoA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               mp.start();
                parametrosA(1,2,"Bloque A","Planos");

            }
        });
        cardOficinaA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosA(1,5,"Bloque A","Oficinas");


            }
        });
        cardLabA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosA(1,4,"Bloque A","Laboratorios");

            }
        });
        cardOtrosA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosA(1,6,"Bloque A","Cafeteria/Papeleria/baños");

            }
        });
        cardAuditorioA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosA(1,7,"Bloque A","Auditorio");

            }
        });
        cardAulasA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosA(1,3,"Bloque A","Aulas");

            }
        });

    }

    // metodo que conecta la vista mainactivity desde un fragment por medio de una instacia, para llamar
    // al metodo updateview que esta en mainactivty para actulizar el titulo y subtilo de la vista, seleccioanada
    // de acuerod al fragmento seleccionado.

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getActivity() instanceof MainActivity) {
            MainActivity activity = (MainActivity) getActivity();
            activity.updateView(getString(R.string.sede1),getString(R.string.bloquea));
            activity.navigationView.setCheckedItem(R.id.nav_bloqueA);

        }
    }

    // metodo para enviar los parametos a la clase DetalleActivity.

    public void parametrosA(int bloque,int dependencia, String sede, String opcion)
    {
        Intent intent= new Intent(getContext(),DetalleActivity.class);
        intent.putExtra("bloque",bloque);
        intent.putExtra("dependencia",dependencia);
        intent.putExtra("bloquea",sede);
        intent.putExtra("opcion",opcion);
        startActivity(intent);

    }




}
