package com.example.formativa.guiapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SedeFragmentG extends Fragment {
    private CardView cardPlanoG,cardAulasG,cardOficinaG,cardOtrosG,cardAuditorioG,cardGPG;
    MediaPlayer mp;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.app_bar_sedeg, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        cardPlanoG =(CardView)view.findViewById(R.id.cardIdPlanoG);
        cardOficinaG=(CardView)view.findViewById(R.id.cardIdOfiG);
        cardOtrosG=(CardView)view.findViewById(R.id.cardIdOtrosG);
        cardAuditorioG=(CardView)view.findViewById(R.id.cardIdAuditorioG);
        cardAulasG=(CardView)view.findViewById(R.id.cardIdAulasG);
        cardGPG=(CardView)view.findViewById(R.id.cardIdGymPisG);

        mp=MediaPlayer.create(getContext(),R.raw.click);


        cardPlanoG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosG(6,2,"Bloque G","Planos");

            }
        });
        cardOficinaG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosG(6,5,"Bloque G","Oficinas");


            }
        });

        cardOtrosG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosG(6,6,"Bloque G","Cafeteria/Papeleria/Baños");

            }
        });
        cardAuditorioG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosG(6,7,"Bloque G","Auditorio");

            }
        });
        cardAulasG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosG(6,3,"Bloque G","Aulas");

            }
        });
        cardGPG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosG(6,9,"Bloque G","GYM/Piscina");

            }
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getActivity() instanceof MainActivity) {
            MainActivity activity = (MainActivity) getActivity();
            activity.updateView(getString(R.string.sede4),getString(R.string.bloqueg));
            activity.navigationView.setCheckedItem(R.id.nav_bloqueG);

        }
    }

    public void parametrosG(int bloque,int dependencia, String sede, String opcion)
    {
        Intent intent= new Intent(getContext(),DetalleActivity.class);
        intent.putExtra("bloque",bloque);
        intent.putExtra("dependencia",dependencia);
        intent.putExtra("bloquea",sede);
        intent.putExtra("opcion",opcion);
        startActivity(intent);

    }

}
