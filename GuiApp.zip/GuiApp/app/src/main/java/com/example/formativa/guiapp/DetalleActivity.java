package com.example.formativa.guiapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.example.formativa.guiapp.Adapter.DetalleAdapter;
import com.example.formativa.guiapp.Entidad.Detalle;
import com.example.formativa.guiapp.VolleyService.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DetalleActivity extends AppCompatActivity {

    ProgressDialog progreso;
    StringRequest stringRequest;
    private TextView rta;
    private Bitmap imagen;
    private ImageView imageView;

    ListView mlistView;
    ArrayList<Detalle> mlist;
    DetalleAdapter madapter=null;

    int bloque_id_param=0;
    int tipo_Dependencia_param=0;
    String bloque_x="";
    String dependencia="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mlistView=findViewById(R.id.lista);
        // Parametros que se reciben del de los fragmentos para consultar los servicios y actulixar la vista , como el titulo.
        bloque_id_param=getIntent().getExtras().getInt("bloque");
        tipo_Dependencia_param=getIntent().getExtras().getInt("dependencia");
        bloque_x=getIntent().getExtras().getString("bloquea");
        dependencia=getIntent().getExtras().getString("opcion");

        getSupportActionBar().setTitle(bloque_x+"-"+dependencia);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    // Metodo que consulta los servicios de acuerdo a lo seleccionado en los fragmentos .
       cargarServicioWeb();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    // metodo que se encarga de recorrer el JsonArray que llega del webservice

    public void enviarListaView(String response)
    {
        mlist= new ArrayList<>();
        Detalle detalle=null;

        try {
            JSONObject jsonObject= new JSONObject(response);
            JSONArray jsonArray= jsonObject.optJSONArray("dependencias");

            for (int i=0;i<jsonArray.length();i++)
            {
                // se recorre , y luego se saca cada una de sus propiedad y se envia entidad detalle .
                JSONObject jsoon=null;
                jsoon=jsonArray.getJSONObject(i);


                String id=jsoon.optString("id");
                String name=jsoon.optString("name");
                String location=jsoon.optString("location");
                String imagens=jsoon.optString("img");
                String descripcion=jsoon.optString("description");


                mlist.add(new Detalle(Integer.parseInt(id),name,location,imagens,descripcion));



            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        madapter=new DetalleAdapter(this,R.layout.row,mlist);
        mlistView.setAdapter(madapter);

        mlistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Detalle vista=(Detalle)madapter.getItem(i);
                // llamado del metodo para cargar la iamgen , de la lista .
                cargarImagenWeb(vista.getRutaImagen());

            }
        });
    }

    // Metodo que se encargar de mostar la iamgen , seleccioando de la lista  .


    public void cargarImagenWeb(String rutaImagen)
    {
        progreso=new ProgressDialog(this);
        progreso.setMessage("Cargando Imagen...");
        progreso.setCancelable(false);
        progreso.show();

        String url="http://api.decucuta.com/img/"+rutaImagen;
        url=url.replace(" ","20%");



        ImageRequest imageRequest= new ImageRequest(url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {

                progreso.hide();
                // creamos clase Diaglo para mostar la iamgen, de la lista creeado en layout dialog , vista que me visulizara .
                final Dialog dialog= new Dialog(DetalleActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_LEFT_ICON);
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.dialog);
                ImageView img=(ImageView)dialog.findViewById(R.id.vista_img_diag);

                Button btn=(Button)dialog.findViewById(R.id.btn_diag);
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                img.setImageBitmap(response);


                dialog.show();



            }
        }, 0, 0, ImageView.ScaleType.CENTER, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(),"Error al cargar la Iamgen",Toast.LENGTH_SHORT).show();

            }
        });

        VolleySingleton.getIntanciaVolley(this).addToRequestQueue(imageRequest);
    }



    private void cargarServicioWeb()
    {
        progreso=new ProgressDialog(this);
        progreso.setMessage("Cargando...");
        progreso.setCancelable(false);
        progreso.show();
        // url base para consultar los servicios por metodo post .

        String url="http://api.decucuta.com/api/dependencias/dependenciasPorTipo";
        //String url="http://192.168.12.90:8080/save_inf/insert.php?";

        stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progreso.hide();

                // la respuesta que llega sera enviado a un metodo enviarListaView para recorrer al Json que llega en forma de array .

            enviarListaView(response);




            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(),"Error en la conexion",Toast.LENGTH_SHORT).show();
                progreso.hide();

            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                // Metodo de enviar los parametos , en el cual se consultara el servicio.


                Map<String,String> parametros=new HashMap<>();
                String bloque_id=String.valueOf(bloque_id_param);
                String tipoDependencia=String.valueOf(tipo_Dependencia_param);

                parametros.put("bloque_id",bloque_id);
                parametros.put("tipoDependencia",tipoDependencia);


                return parametros;
            }



        };
        // tiempo de esperar para cargar servicio y agregado stringrequest

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(DefaultRetryPolicy.DEFAULT_TIMEOUT_MS*2,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getIntanciaVolley(getApplicationContext()).addToRequestQueue(stringRequest);

    }


}
