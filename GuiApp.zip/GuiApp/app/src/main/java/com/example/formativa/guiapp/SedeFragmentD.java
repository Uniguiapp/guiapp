package com.example.formativa.guiapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SedeFragmentD extends Fragment {

    private CardView cardPlanoD,cardOficinaD,cardAulasD,cardBiblioD;
    MediaPlayer mp;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.app_bar_seded, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        cardPlanoD =(CardView)view.findViewById(R.id.cardIdPlanoD);
        cardOficinaD=(CardView)view.findViewById(R.id.cardIdOfiD);
        cardAulasD=(CardView)view.findViewById(R.id.cardIdAulasD);
        cardBiblioD=(CardView)view.findViewById(R.id.cardIdBiblioD);

        mp=MediaPlayer.create(getContext(),R.raw.click);


        cardPlanoD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosD(4,2,"Bloque D","Planos");

            }
        });
        cardBiblioD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosD(4,8,"Bloque D","Biblioteca");

            }
        });
        cardOficinaD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosD(4,5,"Bloque D","Oficinas");


            }
        });

        cardAulasD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosD(4,3,"Bloque D","Aulas");

            }
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getActivity() instanceof MainActivity) {
            MainActivity activity = (MainActivity) getActivity();
            activity.updateView(getString(R.string.sede2),getString(R.string.bloqued));
            activity.navigationView.setCheckedItem(R.id.nav_bloqueD);

        }
    }

    public void parametrosD(int bloque,int dependencia, String sede, String opcion)
    {
        Intent intent= new Intent(getContext(),DetalleActivity.class);
        intent.putExtra("bloque",bloque);
        intent.putExtra("dependencia",dependencia);
        intent.putExtra("bloquea",sede);
        intent.putExtra("opcion",opcion);
        startActivity(intent);

    }

}
