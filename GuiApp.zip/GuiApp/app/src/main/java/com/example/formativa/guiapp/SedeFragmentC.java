package com.example.formativa.guiapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SedeFragmentC extends Fragment {
    private CardView cardPlanoC,cardOficinaC,cardOtrosC,cardAulasC;
    MediaPlayer mp;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.app_bar_sedec, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        cardPlanoC =(CardView)view.findViewById(R.id.cardIdPlanoC);
        cardOficinaC=(CardView)view.findViewById(R.id.cardIdOfiC);
        cardOtrosC=(CardView)view.findViewById(R.id.cardIdOtrosC);
        cardAulasC=(CardView)view.findViewById(R.id.cardIdAulasC);

        mp=MediaPlayer.create(getContext(),R.raw.click);


        cardPlanoC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosC(3,2,"Bloque C","Planos");

            }
        });
        cardOficinaC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosC(3,5,"Bloque C","Oficinas");


            }
        });

        cardOtrosC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosC(3,6,"Bloque C","Cafeteria/Papeleria/baños");

            }
        });

        cardAulasC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mp.start();
                parametrosC(3,3,"Bloque C","Aulas");

            }
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getActivity() instanceof MainActivity) {
            MainActivity activity = (MainActivity) getActivity();
            activity.updateView(getString(R.string.sede2),getString(R.string.bloquec));
            activity.navigationView.setCheckedItem(R.id.nav_bloqueC);

        }
    }

    public void parametrosC(int bloque,int dependencia, String sede, String opcion)
    {
        Intent intent= new Intent(getContext(),DetalleActivity.class);
        intent.putExtra("bloque",bloque);
        intent.putExtra("dependencia",dependencia);
        intent.putExtra("bloquea",sede);
        intent.putExtra("opcion",opcion);
        startActivity(intent);

    }

}
