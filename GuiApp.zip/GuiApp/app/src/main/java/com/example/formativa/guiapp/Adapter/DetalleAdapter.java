package com.example.formativa.guiapp.Adapter;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.NetworkImageView;
import com.example.formativa.guiapp.Entidad.Detalle;
import com.example.formativa.guiapp.R;
import com.example.formativa.guiapp.VolleyService.VolleySingleton;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetalleAdapter extends BaseAdapter {

    // Permite la comunicacion en tre dos vistas diferentes
    // se crea el conexto un array y los metodo propios del baseAdapter.
    private Context context;
    private int layout;
    private ArrayList<Detalle> detalleList;
    ProgressDialog progreso;
    Bitmap imgbitmap;
    Bitmap[] bitmapArray={};
   ArrayList<Bitmap> temp=new ArrayList<Bitmap>();


    public DetalleAdapter(Context context, int layout, ArrayList<Detalle> detalleList) {
        this.context = context;
        this.layout = layout;
        this.detalleList = detalleList;
    }

    @Override
    public int getCount() {
        return detalleList.size();
    }

    @Override
    public Object getItem(int i) {
        return detalleList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    private class ViewHolder
    {
        // se crear componente que se van visulizar o mostrar .

        TextView txtnombre;
        TextView txtlocation;
        TextView textdescripcion;

        CircleImageView circleImageView;


    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row==null)
        {
            // infla la vista row, para luego instacniar sus componente conla clase holder creada.
            LayoutInflater inflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row= inflater.inflate(layout,null);


            holder.txtnombre= row.findViewById(R.id.name_list);
            holder.textdescripcion= row.findViewById(R.id.descrip_list);
            holder.txtlocation= row.findViewById(R.id.loc_list);

            // holder.imageView=row.findViewById(R.id.imagenIcon);
            holder.circleImageView=row.findViewById(R.id.imag_list);

            row.setTag(holder);

        }else
        {
            holder=(ViewHolder)row.getTag();
        }
        // pregunta si la ruta de la iamgen es diferente de null, para llamar al metodo cargarImagenWeb .

        if (detalleList.get(i).getRutaImagen()!=null)
        {
            cargarImagenWeb(detalleList.get(i).getRutaImagen(),holder,detalleList,i);


        }else
            {
                // de lo contrario en la vista severa reflajado el icono de la aplicacion .
                holder.circleImageView.setImageResource(R.mipmap.ic_launcher_round);
            }



        return row;
    }

    // metodo de cargar la iamgen, que recibe la rura ,lista y posicion .

    public void cargarImagenWeb(String rutaImagen, final ViewHolder holder, final ArrayList<Detalle>list, final int position)
    {
        // ruta base mas ruta de la imagen que llega , para hacer consultada y cargada en circleImageView .
        String url="http://api.decucuta.com/img/"+rutaImagen;
        url=url.replace(" ","20%");



        ImageRequest imageRequest= new ImageRequest(url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {

                Detalle detalle=list.get(position);

                // se cambia el tama;o de la iamgen para ser obtener mejor rendimeinto de app.

                imgbitmap=getResizeBitmap(response,250);

                if (imgbitmap!=null)
                {
                    // una vez cargada la iamgen se visuliza con los datos guradador en la clase Detalle que se mapeo .

                    holder.circleImageView.setImageBitmap(imgbitmap);

                    holder.txtnombre.setText(detalle.getNombre());
                    holder.txtlocation.setText(detalle.getUbicacion());
                    holder.textdescripcion.setText(detalle.getDescripcion());
                }


            }
        }, 0, 0, ImageView.ScaleType.CENTER, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context,"Error al cargar la Iamgen",Toast.LENGTH_SHORT).show();

            }
        });

        VolleySingleton.getIntanciaVolley(context).addToRequestQueue(imageRequest);
    }
    // Metodo cambiar el tama;os de la imagen, reciviendo bitmap y tama;o.

    public Bitmap getResizeBitmap(Bitmap img,int maxSize)
    {
        int width=img.getWidth();
        int heigth=img.getHeight();

        float bitmapRatio=(float)width/(float) heigth;
        if (bitmapRatio>1)
        {
            width=maxSize;
            heigth=(int)(width / bitmapRatio);
        }else
        {
            heigth=maxSize;
            width=(int)(heigth * bitmapRatio);
        }

        return Bitmap.createScaledBitmap(img,width,heigth,true);

    }
}
